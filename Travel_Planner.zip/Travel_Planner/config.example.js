module.exports.flights = 'YOUR_KEY_HERE';  //Google QPX API
module.exports.APCAuth = 'YOUR_KEY_HERE';  //Air-port-code Auth
module.exports.APCSecret = 'YOUR_KEY_HERE'; //Air-port-code Secret
module.exports.yelpKey = 'YOUR_KEY_HERE'; //Yelp Fusion API
module.exports.hotelkey = 'YOUR_KEY_HERE'; //Yelp Fusion API
module.exports.darkskyAPI = 'YOUR_KEY_HERE'; //Dark Sky API
module.exports.geolocationAPI = 'YOUR_KEY_HERE';  //Google Geo Coding API
